package com.example.mylogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {
    private int counter = 3 ;
    private  TextView info = (TextView)findViewById(R.id.button);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText user = (EditText) findViewById(R.id.userName);
        final EditText pass = (EditText) findViewById(R.id.password);
        final TextView MM = (TextView) findViewById(R.id.textView3);
        Button login = (Button) findViewById(R.id.button);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(user.getText().toString(), pass.getText().toString());
            }

        });
    }

        private void validate (String userName,String password){
        if ((userName.equals("mohammed"))&&
                (password.equals("123"))) {
            Intent i = new Intent(getApplicationContext(), Main2Activity.class);
            startActivity(i);
        } else {
                        counter--;
                        info.setText("text"+String.valueOf(counter));
            }
        }
    }

